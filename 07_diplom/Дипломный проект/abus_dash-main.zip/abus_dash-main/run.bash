python3 -m venv my_env1
source my_env1/bin/activate
pip3 install -r requirements.txt
python3 app.py