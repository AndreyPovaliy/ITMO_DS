import os
import pandas as pd


df = pd.read_csv('data/us_data.csv')

